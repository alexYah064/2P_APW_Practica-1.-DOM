// 1a. Cambia el contenido (el innerHTML) del elemento <p> con id="demo".
document.getElementById("demo").innerHTML = "¡Hola Mundo!";

// 1b. Busca el elemento con id="intro".
const elemento = document.getElementById("intro1b");
elemento.innerHTML = "sopa nissin con maruchan";

// 1c. Cambia el elemento de una etiqueta <p> con id="P1".
document.getElementById("P1").innerHTML = "¡Nuevo Texto tilin!";

// 1d. Cambia el contenido de un elemento <h1> con id="titulo".
const elemento1d = document.getElementById("titulo");
elemento1d.innerHTML = "Nuevo Encabezado";

// 2b. Encuentra el elemento con id="Main" y luego encuentra todos los elementos <p> dentro del main.
const x = document.getElementById("main");
const y = x.getElementsByTagName("p");
console.log(y);

// 3a. Encuentra todos los elementos con el mismo nombre de clase "Intro".
const x3a = document.getElementsByClassName("Intro3a");
console.log(x3a);

// 4a. Devuelve una lista de todos los elementos <p> con class="intro".
const x4a = document.querySelectorAll("p.intro");
console.log(x4a);

// 4b. Encuentra los elementos <li> hijos de <ul>.
const listItems = document.querySelectorAll("ul > li");
console.log(listItems);

// 4c. Encontrar en la consola e imprimir el elemento <h1>.
const h1Element = document.querySelector("h1");
console.log(h1Element);

// 4d. Encontrar la clase list usando querySelector().
const list = document.querySelector(".list");
console.log(list);

// 4e. Imprimir los elementos <li> haciendo uso del ciclo forEach().
const listaDeElementos = document.querySelectorAll("ul > li");
listaDeElementos.forEach((item) => {
    console.log(item);
});

// 4f. Uso de la propiedad style para cambiar estilos en línea CSS.
const h1 = document.querySelector("h1");
h1.style.color = "green";

// 5a. Encuentra el elemento de formulario con id="frm1" y muestra todos los valores de los elementos.
const x5a = document.forms["frm1"];
let texto = "";
for (let i = 0; i < x5a.length; i++) {
    texto += x5a.elements[i].value + "<br>";
}
document.getElementById("demo").innerHTML = texto;
console.log(x5a);

// 6a. Agregar elementos al árbol del DOM.
let lista = document.createElement("ul");
document.body.appendChild(lista);

let elemento1 = document.createElement("li");
elemento1.textContent = "Flor";
lista.appendChild(elemento1);

let elemento2 = document.createElement("li");
elemento2.textContent = "Jaguar";
lista.appendChild(elemento2);

// 7a. Crear un botón en el documento HTML, donde al hacer click aparezca un mensaje de alerta.
const button = document.getElementById("btn");
button.addEventListener("click", () => {
    alert("Gracias por dar click");
});

// 8a. Validación de formulario.
function validarFormulario() {
    let x = document.forms["miFormulario"]["nombre"].value;
    if (x === "") {
        alert("Se debe completar el nombre");
        return false;
    }
}

// 8b. Valida la entrada numérica que valide que la entrada sea numérica y que esté en un rango entre 1 y 10.
function miFuncion() {
    let x = document.getElementById("numero").value;
    let texto;
    if (isNaN(x) || x < 1 || x > 10) {
        texto = "Entrada no válida";
    } else {
        texto = "Entrada correcta";
    }
    document.getElementById("demo8b").innerHTML = texto;
}

// 9. Cambiar el valor de un atributo src de un elemento <img>.
document.getElementById("miamigen").src = "njsajxnja.webp";

// 10. Agregar la hora actual a una etiqueta con id="demo".
document.getElementById("demo10a").innerHTML = "Fecha: " + new Date();

